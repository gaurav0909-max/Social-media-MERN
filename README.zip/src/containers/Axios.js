// import axios from "axios";
// import { useEffect } from "react";

// function Axios() {
//     useEffect(() => {
//         axios.get('http://localhost:3001/message',{
//           email: email,
//           password: password
//         })
//           .then((data) => setData(data));
//       },[])
//   return (
//     <div>
      
//     </div>
//   )
// }

// export default Axios
