import React from 'react'

function Footer() {
  return (
    <div>
      This is Footer it is appear only when you are on small devices.
    </div>
  )
}

export default Footer
